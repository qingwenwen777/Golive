import {
  type ChangeEvent,
  type ReactNode,
  useEffect,
  useRef,
  useState,
} from 'react';
import { ImagePlus } from 'lucide-react';
import { cn } from '@/lib/cn';

export interface ImageCropConfig {
  aspectRatio: number;
  outputWidth: number;
  outputHeight: number;
  quality: number;
  mimeType?: 'image/jpeg' | 'image/webp';
}

export interface ImageCropSelection {
  file: File;
  url: string;
  naturalWidth: number;
  naturalHeight: number;
  zoom: number;
  offsetX: number;
  offsetY: number;
}

interface ImageCropFieldProps {
  accept: string;
  active: boolean;
  className?: string;
  config: ImageCropConfig;
  disabled?: boolean;
  emptyLabel: string;
  fallback?: ReactNode;
  pickLabel: string;
  shape?: 'circle' | 'rect';
  validateFile: (file: File) => string | null;
  onError: (message: string | null) => void;
  onSelectionChange: (selection: ImageCropSelection | null) => void;
}

export function ImageCropField({
  accept,
  active,
  className,
  config,
  disabled,
  emptyLabel,
  fallback,
  pickLabel,
  shape = 'rect',
  validateFile,
  onError,
  onSelectionChange,
}: ImageCropFieldProps) {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const imageRef = useRef<HTMLImageElement | null>(null);
  const fileUrlRef = useRef('');
  const [selection, setSelection] = useState<ImageCropSelection | null>(null);

  const clearSelection = () => {
    imageRef.current = null;
    setSelection(null);
    onSelectionChange(null);
    if (fileUrlRef.current) {
      URL.revokeObjectURL(fileUrlRef.current);
      fileUrlRef.current = '';
    }
  };

  useEffect(() => {
    if (!active) {
      clearSelection();
      onError(null);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [active]);

  useEffect(() => {
    onSelectionChange(selection);
    const canvas = canvasRef.current;
    const image = imageRef.current;
    if (!canvas || !image || !selection) return;
    drawCroppedImage(canvas, image, selection, config);
  }, [config, onSelectionChange, selection]);

  useEffect(() => () => clearSelection(), []);

  const handleFile = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0] ?? null;
    event.target.value = '';
    onError(null);

    if (!file) {
      clearSelection();
      return;
    }

    const validationError = validateFile(file);
    if (validationError) {
      clearSelection();
      onError(validationError);
      return;
    }

    if (fileUrlRef.current) URL.revokeObjectURL(fileUrlRef.current);
    const url = URL.createObjectURL(file);
    fileUrlRef.current = url;

    const image = new Image();
    image.onload = () => {
      imageRef.current = image;
      setSelection({
        file,
        url,
        naturalWidth: image.naturalWidth,
        naturalHeight: image.naturalHeight,
        zoom: 1,
        offsetX: 0,
        offsetY: 0,
      });
    };
    image.onerror = () => {
      clearSelection();
      onError('无法读取这张图片，请换一张试试。');
    };
    image.src = url;
  };

  const updateSelection = (patch: Partial<Pick<ImageCropSelection, 'zoom' | 'offsetX' | 'offsetY'>>) => {
    setSelection((current) => (current ? { ...current, ...patch } : current));
  };

  return (
    <div className={cn('gl-image-crop-field', className)}>
      <label className={cn('gl-image-crop-pick', shape === 'circle' && 'is-circle')}>
        <span className="gl-image-crop-stage">
          {selection ? (
            <canvas
              ref={canvasRef}
              className="gl-image-crop-canvas"
              width={config.outputWidth}
              height={config.outputHeight}
            />
          ) : fallback ? (
            fallback
          ) : (
            <span className="gl-image-crop-empty">
              <ImagePlus size={24} />
              {emptyLabel}
            </span>
          )}
        </span>
        <span className="gl-avatar-pick-btn">
          <ImagePlus size={16} />
          {pickLabel}
        </span>
        <input type="file" accept={accept} disabled={disabled} onChange={handleFile} />
      </label>

      {selection && (
        <div className="gl-image-crop-controls">
          <label>
            <span>缩放</span>
            <input
              type="range"
              min="1"
              max="2.8"
              step="0.01"
              value={selection.zoom}
              onChange={(event) => updateSelection({ zoom: Number(event.target.value) })}
            />
          </label>
          <label>
            <span>左右</span>
            <input
              type="range"
              min="-1"
              max="1"
              step="0.01"
              value={selection.offsetX}
              onChange={(event) => updateSelection({ offsetX: Number(event.target.value) })}
            />
          </label>
          <label>
            <span>上下</span>
            <input
              type="range"
              min="-1"
              max="1"
              step="0.01"
              value={selection.offsetY}
              onChange={(event) => updateSelection({ offsetY: Number(event.target.value) })}
            />
          </label>
        </div>
      )}
    </div>
  );
}

export async function cropSelectionToFile(
  selection: ImageCropSelection,
  config: ImageCropConfig,
  filenamePrefix: string,
): Promise<File> {
  const image = await loadImage(selection.url);
  const canvas = document.createElement('canvas');
  canvas.width = config.outputWidth;
  canvas.height = config.outputHeight;
  drawCroppedImage(canvas, image, selection, config);

  const mimeType = config.mimeType ?? 'image/jpeg';
  const blob = await new Promise<Blob>((resolve, reject) => {
    canvas.toBlob(
      (next) => {
        if (next) resolve(next);
        else reject(new Error('Could not process image.'));
      },
      mimeType,
      config.quality,
    );
  });
  const ext = mimeType === 'image/webp' ? 'webp' : 'jpg';
  return new File([blob], `${filenamePrefix}-${Date.now()}.${ext}`, {
    type: mimeType,
    lastModified: Date.now(),
  });
}

function loadImage(url: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const image = new Image();
    image.onload = () => resolve(image);
    image.onerror = () => reject(new Error('Could not load image.'));
    image.src = url;
  });
}

function drawCroppedImage(
  canvas: HTMLCanvasElement,
  image: HTMLImageElement,
  selection: ImageCropSelection,
  config: ImageCropConfig,
) {
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  const crop = resolveCrop(selection, config.aspectRatio);
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.fillStyle = '#fff';
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';
  ctx.drawImage(
    image,
    crop.x,
    crop.y,
    crop.width,
    crop.height,
    0,
    0,
    canvas.width,
    canvas.height,
  );
}

function resolveCrop(selection: ImageCropSelection, aspectRatio: number) {
  const sourceRatio = selection.naturalWidth / selection.naturalHeight;
  let baseWidth = selection.naturalWidth;
  let baseHeight = selection.naturalHeight;

  if (sourceRatio > aspectRatio) {
    baseWidth = selection.naturalHeight * aspectRatio;
  } else {
    baseHeight = selection.naturalWidth / aspectRatio;
  }

  const width = Math.max(1, Math.min(selection.naturalWidth, baseWidth / selection.zoom));
  const height = Math.max(1, Math.min(selection.naturalHeight, baseHeight / selection.zoom));
  const maxX = Math.max(0, selection.naturalWidth - width);
  const maxY = Math.max(0, selection.naturalHeight - height);
  const x = clamp(maxX / 2 + selection.offsetX * (maxX / 2), 0, maxX);
  const y = clamp(maxY / 2 + selection.offsetY * (maxY / 2), 0, maxY);

  return { x, y, width, height };
}

function clamp(value: number, min: number, max: number) {
  return Math.min(max, Math.max(min, value));
}
